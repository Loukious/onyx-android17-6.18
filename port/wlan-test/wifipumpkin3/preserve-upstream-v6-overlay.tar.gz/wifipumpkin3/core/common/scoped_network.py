"""Own only one AP's IPv4 configuration in an existing network namespace.

No shell commands, interface-name heuristics, global firewall flushes, or
default routing/policy changes. The journal retains exact inverse commands
for root-owned recovery if the application is killed before normal cleanup.
"""
import atexit
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import subprocess
import sys


class ScopedNetwork:
    FORWARD = Path("/proc/sys/net/ipv4/ip_forward")

    def __init__(self, ap, upstream, router, netmask, iptables, state_dir, bssid):
        for name in (ap, upstream):
            if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,15}", name):
                raise ValueError("Select explicit AP and upstream interface names")
        if ap == upstream:
            raise ValueError("The AP and upstream must be different interfaces")
        self.ap, self.upstream = ap, upstream
        self.address = ipaddress.IPv4Interface("{}/{}".format(router, netmask))
        self.network = self.address.network
        if self.address.ip in (self.network.network_address, self.network.broadcast_address):
            raise ValueError("AP address must be a usable subnet address")
        self.ip = shutil.which("ip")
        if not self.ip or not iptables or not os.path.isfile(iptables):
            raise ValueError("ip and the selected iptables backend are required")
        self.iptables = iptables
        self.bssid = bssid.lower()
        self.token = secrets.token_hex(5).upper()
        self.journal = Path(state_dir) / ("scoped-network-" + self.token + ".json")
        self.undo = []
        self.plan = []
        self.before = {}
        self.route_cleanup_observations = []
        self.owner = os.getpid()
        self.status = "preflight"

    def run(self, argv):
        result = subprocess.run(argv, text=True, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, timeout=10)
        if result.returncode:
            raise RuntimeError("{}: {}".format(" ".join(argv), result.stderr.strip()))
        return result.stdout

    def query(self, *argv, ipv4=True):
        return json.loads(self.run([self.ip, "-j", *(["-4"] if ipv4 else []), *argv]))

    def identity(self, name):
        # An existing down/address-free AP may be absent from `ip -4 address`.
        # Link identity and flags must come from the family-independent view.
        records = self.query("link", "show", "dev", name, ipv4=False)
        if len(records) != 1:
            raise RuntimeError("Interface identity is unavailable: " + name)
        link = dict(records[0])
        addresses = self.query("address", "show", "dev", name)
        if len(addresses) > 1 or (addresses and addresses[0].get("ifindex") != link["ifindex"]):
            raise RuntimeError("Interface changed during IPv4 lookup: " + name)
        link["addr_info"] = addresses[0].get("addr_info", []) if addresses else []
        return link, (link["ifindex"], link["address"].lower())

    def check_ap(self):
        if self.identity(self.ap)[1] != tuple(self.before["ap_identity"]):
            raise RuntimeError("AP interface was replaced; refusing to change its addresses or link")

    def save(self):
        data = {"schema": "wifipumpkin3-scoped-network/v1", "status": self.status,
                "pid": self.owner, "ap": self.ap, "upstream": self.upstream,
                "token": self.token, "before": self.before,
                "planned": self.plan, "pending_cleanup": self.undo,
                "route_cleanup_observations": self.route_cleanup_observations}
        temporary = self.journal.with_suffix(".new")
        with temporary.open("w") as stream:
            os.chmod(temporary, 0o600)
            json.dump(data, stream, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, self.journal)

    def prepare(self):
        ap, ap_identity = self.identity(self.ap)
        upstream, upstream_identity = self.identity(self.upstream)
        if ap_identity == upstream_identity or ap_identity[1] != self.bssid:
            raise ValueError("Use the existing AP interface's own MAC as the hostapd BSSID")
        if "UP" not in upstream.get("flags", []):
            raise ValueError("The selected upstream interface is not up")
        if ap.get("addr_info"):
            raise ValueError("Preserved-upstream mode requires an AP interface without IPv4 addresses")
        for link in self.query("address", "show"):
            for addr in link.get("addr_info", []):
                existing = ipaddress.IPv4Network("{}/{}".format(addr["local"], addr["prefixlen"]), strict=False)
                if self.network.overlaps(existing):
                    raise ValueError("The AP subnet overlaps an existing interface subnet")
        routes = self.query("route", "show", "table", "all")
        gateways = {r["gateway"] for r in routes if r.get("dev") == self.upstream
                    and r.get("dst") == "default" and r.get("gateway")}
        if len(gateways) != 1:
            raise ValueError("An unambiguous IPv4 gateway is required on the selected upstream")
        gateway = ipaddress.IPv4Address(gateways.pop())
        addresses = [ipaddress.IPv4Interface("{}/{}".format(a["local"], a["prefixlen"]))
                     for a in upstream.get("addr_info", [])]
        addresses = [a for a in addresses if gateway in a.network]
        if len(addresses) != 1:
            raise ValueError("Cannot match the upstream gateway to a connected IPv4 address")
        uplink = addresses[0]
        rules = self.query("rule", "show")
        tables = {str(r.get("table", 254)) for r in routes + rules}
        priorities = {r["priority"] for r in rules}
        table = next((i for i in range(52000, 53000) if str(i) not in tables), None)
        priority = next((i for i in range(17500, 18500, 2)
                         if i not in priorities and i + 1 not in priorities), None)
        if table is None or priority is None:
            raise RuntimeError("No unused scoped routing table/priority pair is available")
        forward = self.FORWARD.read_text().strip()
        if forward not in ("0", "1"):
            raise RuntimeError("Cannot determine the existing IPv4 forwarding setting")
        self.before = {"ap_identity": ap_identity, "upstream_identity": upstream_identity,
                       "ap_up": "UP" in ap.get("flags", []), "ip_forward": forward,
                       "table": table, "priority": priority, "gateway": str(gateway),
                       "upstream_address": str(uplink), "ap_address": str(self.address)}
        ip = [self.ip, "-4"]

        def add(command, inverse, ap_change=False):
            self.plan.append({"command": command, "inverse": inverse, "ap_change": ap_change})

        if not self.before["ap_up"]:
            add(ip + ["link", "set", "dev", self.ap, "up"],
                ip + ["link", "set", "dev", self.ap, "down"], True)
        add(ip + ["address", "add", str(self.address), "dev", self.ap],
            ip + ["address", "del", str(self.address), "dev", self.ap], True)
        # hostapd may cycle the AP link after this setup. Linux removes explicit
        # AP routes on link-down, but recreates the address's connected main-table
        # route on link-up. Use that route for AP replies instead of owning a
        # private-table copy which can disappear before traffic or cleanup.
        for route in ([str(uplink.network), "dev", self.upstream, "src", str(uplink.ip)],
                      ["default", "via", str(gateway), "dev", self.upstream]):
            add(ip + ["route", "add", "table", str(table)] + route,
                ip + ["route", "del", "table", str(table)] + route)
        for rule in (["priority", str(priority), "from", str(self.network), "iif", self.ap, "lookup", str(table)],
                     ["priority", str(priority + 1), "to", str(self.network), "lookup", "main"]):
            add(ip + ["rule", "add"] + rule, ip + ["rule", "del"] + rule)
        chains = {"input": "WP3_" + self.token + "_I", "forward": "WP3_" + self.token + "_F",
                  "nat": "WP3_" + self.token + "_N"}

        def firewall(table_name, operation, args):
            inverse = {"-N": "-X", "-A": "-D", "-I": "-D"}[operation]
            prefix = [self.iptables, "-w", "5", "-t", table_name]
            add(prefix + [operation] + args, prefix + [inverse] + args)

        for name, chain in chains.items():
            firewall("nat" if name == "nat" else "filter", "-N", [chain])
        firewall("filter", "-A", [chains["input"], "-p", "udp", "--sport", "68", "--dport", "67", "-j", "ACCEPT"])
        firewall("filter", "-A", [chains["input"], "-s", str(self.network), "-d", str(self.address.ip), "-j", "ACCEPT"])
        firewall("filter", "-A", [chains["forward"], "-j", "ACCEPT"])
        firewall("nat", "-A", [chains["nat"], "-j", "MASQUERADE"])
        firewall("filter", "-I", ["INPUT", "-i", self.ap, "-j", chains["input"]])
        firewall("filter", "-I", ["FORWARD", "-i", self.ap, "-o", self.upstream,
                                   "-s", str(self.network), "-j", chains["forward"]])
        firewall("filter", "-I", ["FORWARD", "-i", self.upstream, "-o", self.ap,
                                   "-d", str(self.network), "-m", "conntrack", "--ctstate",
                                   "RELATED,ESTABLISHED", "-j", chains["forward"]])
        firewall("nat", "-I", ["POSTROUTING", "-s", str(self.network), "-o", self.upstream,
                                "-j", chains["nat"]])
        self.save()

    def start(self):
        self.prepare()
        atexit.register(self.at_exit)
        try:
            for operation in self.plan:
                self.check_ap()
                if self.identity(self.upstream)[1] != tuple(self.before["upstream_identity"]):
                    raise RuntimeError("Upstream interface identity changed during configuration")
                self.run(operation["command"])
                self.undo.append({"argv": operation["inverse"], "ap_change": operation["ap_change"]})
                self.save()
            if self.before["ip_forward"] == "0":
                self.FORWARD.write_text("1\n")
                self.undo.append({"ip_forward": "0"})
                self.save()
            self.status = "active"
            self.save()
            print("[*] Scoped AP networking journal: {}".format(self.journal))
        except BaseException:
            self.close()
            raise

    def close(self):
        if os.getpid() != self.owner or not self.before:
            return
        remaining, errors = [], []
        for operation in reversed(self.undo):
            try:
                if "ip_forward" in operation:
                    current = self.FORWARD.read_text().strip()
                    if current not in ("0", "1"):
                        raise RuntimeError("IPv4 forwarding state is unavailable")
                    if current != operation["ip_forward"]:
                        self.FORWARD.write_text(operation["ip_forward"] + "\n")
                else:
                    if operation["ap_change"]:
                        self.check_ap()
                    argv = operation["argv"]
                    if argv[:4] != [self.ip, "-4", "route", "del"] or self.owned_route_present(argv):
                        self.run(argv)
            except Exception as error:
                remaining.append(operation)
                errors.append(str(error))
        self.undo = list(reversed(remaining))
        self.status = "cleanup_incomplete" if errors else "restored"
        self.save()
        if errors:
            raise RuntimeError("Scoped cleanup incomplete; keep journal {}: {}".format(self.journal, "; ".join(errors)))

    def owned_route_present(self, argv):
        """Delete only the expected owned route, or prove it already absent.

        Kernel STA teardown can remove a route using the old source address.
        Do not turn ESRCH into success: query the actual table before deletion,
        record its state, and refuse a same-prefix replacement or query failure.
        A deletion race remains a cleanup error and can be retried with a new
        authoritative query. No foreign route is deleted or normalized away.
        """
        if len(argv) < 9 or argv[4] != "table" or argv[5] != str(self.before["table"]):
            raise RuntimeError("Route inverse does not address our reserved table")
        expected = {"table": argv[5], "dst": argv[6], "dev": argv[argv.index("dev") + 1]}
        for option, key in (("via", "gateway"), ("src", "prefsrc")):
            if option in argv:
                expected[key] = argv[argv.index(option) + 1]
        routes = self.query("route", "show", "table", "all")
        table_routes = [route for route in routes if str(route.get("table", "main")) == argv[5]]
        def prefix(value):
            return ipaddress.IPv4Network("0.0.0.0/0" if value == "default" else value)
        matches = [route for route in table_routes if prefix(route.get("dst", "default")) == prefix(expected["dst"])]
        observation = {"expected": expected, "observed_table_routes": table_routes,
                       "action": "already_absent" if not matches else "verify_before_delete"}
        self.route_cleanup_observations.append(observation)
        if not matches:
            return False
        allowed = {"table", "dst", "dev", "gateway", "prefsrc", "protocol", "scope", "flags", "type", "metric"}
        scope = "global" if "gateway" in expected else "link"
        if (len(matches) != 1 or set(matches[0]) - allowed or
                any(matches[0].get(key) != expected.get(key) for key in ("dev", "gateway", "prefsrc")) or
                matches[0].get("protocol", "boot") != "boot" or matches[0].get("scope", "global") != scope or
                matches[0].get("type", "unicast") != "unicast" or matches[0].get("metric", 0) != 0 or
                matches[0].get("flags", []) not in ([], ["linkdown"])):
            observation["action"] = "foreign_replacement_refused"
            raise RuntimeError("Owned route was replaced; refusing cleanup: {}".format(expected))
        observation["action"] = "delete_verified"
        return True

    def at_exit(self):
        if self.undo:
            try:
                self.close()
            except Exception as error:
                print(error, file=sys.stderr)


def validate_services(conf):
    """Reject interception backends whose firewall ownership is not scoped."""
    if not conf.get("ap_mode", "static", format=bool):
        raise ValueError("Preserved-upstream mode currently supports static AP mode")
    if not conf.get("proxy_plugins", "noproxy", format=bool):
        raise ValueError("Select noproxy; preserved-upstream mode still provides routed NAT")
    for group in ("proxy_plugins", "mitm_modules"):
        for name in conf.get_all_childname(group):
            if name != "noproxy" and conf.get(group, name, format=bool):
                raise ValueError("Disable {} before using preserved-upstream mode".format(name))
    if not conf.get("accesspoint", "pydhcp_server", format=bool) or conf.get("accesspoint", "dhcpd_server", format=bool):
        raise ValueError("Select Wifipumpkin3's Python DHCP server for preserved-upstream mode")
    if (not conf.get("accesspoint", "lab_dhcp", format=bool) and
            not conf.get("accesspoint", "pydns_server", format=bool) and
            not (conf.get("accesspoint", "dhcp_dns") or "").split()):
        raise ValueError("Supply --dhcp-dns when the local DNS server is disabled")
